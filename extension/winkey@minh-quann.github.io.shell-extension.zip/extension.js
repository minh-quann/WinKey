import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';
import Clutter from 'gi://Clutter';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';

export default class WinKeyExtension extends Extension {
    constructor(metadata) {
        super(metadata);
        this._capturedEventId = 0;
        this._superHeld = false;
        this._savedIndex = null;
        this._inputSettings = null;
        this._extSettings = null;
    }

    _getCurrentIndex() {
        return this._inputSettings.get_uint('current');
    }

    _setCurrentIndex(index) {
        this._inputSettings.set_uint('current', index);
    }

    _onCapturedEvent(actor, event) {
        const isEnabled = this._extSettings.get_boolean('enabled');
        if (!isEnabled) return Clutter.EVENT_PROPAGATE;

        const type = event.type();
        if (type !== Clutter.EventType.KEY_PRESS && type !== Clutter.EventType.KEY_RELEASE) {
            return Clutter.EVENT_PROPAGATE;
        }

        const keyval = event.get_key_symbol();
        const isSuper = (keyval === Clutter.KEY_Super_L || keyval === Clutter.KEY_Super_R);

        if (!isSuper) {
            return Clutter.EVENT_PROPAGATE;
        }

        if (type === Clutter.EventType.KEY_PRESS && !this._superHeld) {
            this._superHeld = true;
            
            const targetIndex = this._extSettings.get_int('english-index');
            const current = this._getCurrentIndex();
            
            if (current !== targetIndex) {
                this._savedIndex = current;
                this._setCurrentIndex(targetIndex);
            } else {
                this._savedIndex = null;
            }
        } else if (type === Clutter.EventType.KEY_RELEASE && this._superHeld) {
            this._superHeld = false;
            if (this._savedIndex !== null) {
                this._setCurrentIndex(this._savedIndex);
                this._savedIndex = null;
            }
        }

        // Allow GNOME to process the Super key (e.g. to open Overview)
        return Clutter.EVENT_PROPAGATE;
    }

    enable() {
        console.log('[WinKey] Enabling extension');
        this._inputSettings = new Gio.Settings({ schema_id: 'org.gnome.desktop.input-sources' });
        this._extSettings = this.getSettings();
        this._capturedEventId = global.stage.connect('captured-event', this._onCapturedEvent.bind(this));
    }

    disable() {
        console.log('[WinKey] Disabling extension');
        if (this._capturedEventId > 0) {
            global.stage.disconnect(this._capturedEventId);
            this._capturedEventId = 0;
        }
        
        // Restore input source if disabled while holding Super
        if (this._superHeld && this._savedIndex !== null) {
            this._setCurrentIndex(this._savedIndex);
            this._savedIndex = null;
        }
        
        this._superHeld = false;
        this._inputSettings = null;
        this._extSettings = null;
    }
}
